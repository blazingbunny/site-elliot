# Notes for Adrian and Alden (not part of the page Elliot passes on)

- Skill file 1 is `elliot-site-building` on branch `feat/site-template-builder-skill` in `static-sites`. Skill file 2 is `layout-clone-versions` (merged).
- **Not yet confirmed:** that opening the starter folder in the app loads the skills from its `.claude/skills` folder. Test before handing over.
- The starter folder must contain `skins/_kit` (the machine check's project marker) and the content-pack fixtures (`harness/fixtures`). Elliot has no git, so the folder is a plain copy.
- One-time setup on Elliot's laptop: Node 20 or newer, `npm install` in the project and in its `harness` folder, Chrome, the three plugins (`mattpocock-skills`, `modern-web-guidance`, `agentic-sdlc`, which he installs himself in the Claude app), Drive for desktop, and microphone permission for the app. `scripts/setup_check.sh` checks all of it, including `agentic-sdlc`.
- The commands marked "verify on first run" in the skill (`SKILL.md`, "Opening the site in the browser panel") have not been run on Elliot's laptop: the `.claude/launch.json` entries, `npm --prefix harness run dev`, the `env` field for `SKIN`, and the static server for `harness/dist`.
- `agentic-sdlc` writes its own requirement and design documents into the project folder. Decide whether those stay out of the Drive folder (this guide only copies `site/`, `screenshots/`, `spec.md` and `summary.md`) and test the light route on a small site before handover.
- `SKILL.md` and the files in `references/` now cover the spec sheet, the `agentic-sdlc` hand-off, the lint step, the required microphone, the fine-details and polish mission, and the memory note and "same folder" rule.
- Memory is tied to the project folder the app opens. If Elliot opens another folder, his Claude starts with no memory. The one-line instruction to him is in "Memory and starting again". Also confirm the starter folder stays in one fixed place on his laptop.
- The skill has not yet been run with a person.
