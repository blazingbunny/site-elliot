#!/usr/bin/env bash
# One-time machine check for the elliot-site-building skill.
#
# It checks that this computer can build a site and save it to the Drive folder:
#   - node 20 or newer, npm, python3, Google Chrome
#   - the website project folder (package.json and skins/_kit), packages installed, checks installed,
#     the build skill layout-clone-versions
#   - the Claude plugins mattpocock-skills (interview skill), modern-web-guidance (web-quality lint)
#     and agentic-sdlc (the /agentic-sdlc:sdlc build workflow)
#   - the Google Drive folder exists and can be written to
# Read-only: it changes nothing except a short test file it writes into the Drive folder and removes at once.
# It never opens secret or key files.
#
# Usage: bash setup_check.sh [project folder, default .] [Drive folder path]
# One line per check: "PASS <name>", "WARN <name> | <note>" or "FAIL <name> | FIX: <plain words>".
# Last line: "RESULT ready" or "RESULT not ready". Exit code 1 when any check says FAIL.
repo="${1:-.}"
drive="${2:-}"
fail=0
pass() { echo "PASS $1"; }
warn() { echo "WARN $1 | $2"; }
bad()  { echo "FAIL $1 | FIX: $2"; fail=1; }

if command -v node >/dev/null; then
  major=$(node -v | sed 's/^v//; s/\..*//')
  [ "$major" -ge 20 ] && pass "node $(node -v)" || bad "node $(node -v)" "node 20 or newer is needed; install the current LTS version from nodejs.org, then run this check again"
else
  bad node "node is not installed; install the current LTS version from nodejs.org, then run this check again"
fi
command -v npm >/dev/null && pass npm || bad npm "npm is not installed; it comes with node, so install node from nodejs.org"
command -v python3 >/dev/null && pass python3 || bad python3 "python 3 is not installed; install it from python.org, then run this check again"
if command -v google-chrome >/dev/null || command -v chromium >/dev/null || [ -x "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ] || [ -x "/c/Program Files/Google/Chrome/Application/chrome.exe" ]; then
  pass chrome
else
  bad chrome "Google Chrome is needed for the checks and screenshots; install it, then run this check again"
fi

if [ -f "$repo/package.json" ] && [ -d "$repo/skins/_kit" ]; then
  pass "project folder (package.json and skins/_kit present)"
else
  bad "project folder" "open the website project folder as the project in the app; if it is open already, tell Adrian the starting files are incomplete"
fi
[ -d "$repo/node_modules" ] && pass "packages installed" || bad "packages installed" "install it: run npm install once in the project folder"
[ -d "$repo/harness/node_modules" ] && pass "checks installed" || bad "checks installed" "install it: run npm install once in the harness folder inside the project folder"
[ -d "$repo/.claude/skills/layout-clone-versions" ] && pass "build skill present" || bad "build skill" "the build skill is missing from the project folder; tell Adrian the starting files are incomplete"

plug=~/.claude/plugins/cache
ls -d "$plug"/*/mattpocock-skills >/dev/null 2>&1 && pass "plugin mattpocock-skills (interview skill)" || bad "plugin mattpocock-skills" "the interview plugin is not installed; install it in the Claude app (Plugins), then run this check again"
ls -d "$plug"/*/modern-web-guidance >/dev/null 2>&1 && pass "plugin modern-web-guidance" || bad "plugin modern-web-guidance" "the web-quality plugin is not installed; install it in the Claude app (Plugins), then run this check again"
ls -d "$plug"/*/agentic-sdlc >/dev/null 2>&1 && pass "plugin agentic-sdlc (build workflow)" || bad "plugin agentic-sdlc" "the build-workflow plugin (/agentic-sdlc:sdlc) is not installed; install it in the Claude app (Plugins), then run this check again"

if [ -z "$drive" ]; then
  bad "Drive folder" "paste the path of your Google Drive folder for the websites"
elif [ -d "$drive" ]; then
  t="$drive/.write-test-$$"
  if echo ok > "$t" 2>/dev/null; then rm -f "$t"; pass "Drive folder can be written to"; else bad "Drive folder" "the folder exists but cannot be written to; check Google Drive is running and signed in"; fi
else
  bad "Drive folder" "that folder does not exist on this computer; check the path, and that Google Drive for desktop is running"
fi

[ "$fail" = 0 ] && echo "RESULT ready" || echo "RESULT not ready"
exit $fail
